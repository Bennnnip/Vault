/* ternary operator in javascript
is the short form of If-else statement that can only do a simple variable arguments
 */

let flag = true;
let member

if(flag){
    member = "allie";
}else {
    member = "Predator";
}

//simplified with Tertiany operator
member = flag ? "allies" : "Predator";
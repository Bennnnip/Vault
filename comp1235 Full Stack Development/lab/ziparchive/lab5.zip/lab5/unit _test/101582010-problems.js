"use strict";

function calculate(num1, num2) {
    return num1 / num2;
}